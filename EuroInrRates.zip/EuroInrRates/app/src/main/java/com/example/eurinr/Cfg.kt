package com.example.eurinr
import android.content.Context
object Cfg { fun p(c: Context) = c.getSharedPreferences("cfg", 0) }
