package com.example.eurinr

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Currency

object Rates {
    private const val PREFS = "rates"
    private val urls = listOf(
        "https://open.er-api.com/v6/latest/EUR",
        "https://api.frankfurter.dev/v1/latest?base=EUR"
    )

    /** Blocking: run off the main thread. Stores all rates (base EUR). */
    fun fetch(ctx: Context): Boolean {
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val o = JSONObject(c.inputStream.bufferedReader().readText()).getJSONObject("rates")
                c.disconnect()
                o.put("EUR", 1.0)
                ctx.getSharedPreferences(PREFS, 0).edit()
                    .putString("all", o.toString()).putLong("t", System.currentTimeMillis()).apply()
                return true
            } catch (_: Exception) { }
        }
        return false
    }

    fun all(ctx: Context): Map<String, Double> {
        val s = ctx.getSharedPreferences(PREFS, 0).getString("all", null) ?: return emptyMap()
        val o = JSONObject(s)
        return o.keys().asSequence().associateWith { o.getDouble(it) }
    }

    fun cross(m: Map<String, Double>, from: String?, to: String?): Double? {
        val a = m[from]; val b = m[to]
        return if (a != null && b != null && a > 0) b / a else null
    }

    fun time(ctx: Context): Long = ctx.getSharedPreferences(PREFS, 0).getLong("t", 0)

    fun ordered(m: Map<String, Double>): List<String> =
        (if (m.containsKey("USD")) listOf("USD") else emptyList()) + m.keys.filter { it != "USD" }.sorted()

    fun label(code: String): String {
        val n = try { Currency.getInstance(code).displayName } catch (_: Exception) { "" }
        return if (n.isEmpty() || n == code) code else "$code – $n"
    }
}
