package com.example.eurinr

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Rates {
    private const val PREFS = "rates"
    private val urls = listOf(
        "https://api.frankfurter.dev/v1/latest?base=EUR&symbols=INR",
        "https://open.er-api.com/v6/latest/EUR"
    )

    /** Blocking network call: run off the main thread. Returns INR per 1 EUR. */
    fun fetch(ctx: Context): Double? {
        for (u in urls) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                val rate = JSONObject(c.inputStream.bufferedReader().readText())
                    .getJSONObject("rates").getDouble("INR")
                c.disconnect()
                ctx.getSharedPreferences(PREFS, 0).edit()
                    .putLong("r", rate.toRawBits()).putLong("t", System.currentTimeMillis()).apply()
                return rate
            } catch (_: Exception) { }
        }
        return null
    }

    fun cached(ctx: Context): Double? {
        val p = ctx.getSharedPreferences(PREFS, 0)
        return if (p.contains("r")) Double.fromBits(p.getLong("r", 0)) else null
    }

    fun cachedTime(ctx: Context): Long = ctx.getSharedPreferences(PREFS, 0).getLong("t", 0)
}
