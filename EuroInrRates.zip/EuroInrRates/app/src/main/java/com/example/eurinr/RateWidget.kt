package com.example.eurinr

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.util.Locale

class RateWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        draw(ctx, m, ids)
        val pending = goAsync()
        Thread {
            Sync.all(ctx, false)
            draw(ctx, m, ids)
            pending.finish()
        }.start()
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        draw(ctx, m, intArrayOf(id))
    }

    companion object {
        fun redraw(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RateWidget::class.java))
            if (ids.isNotEmpty()) draw(ctx, m, ids)
        }

        private fun bgBitmap(w: Float, h: Float, d: Float, round: Int, color: Int): Bitmap {
            val k = minOf(1f, 600f / (maxOf(w, h) * d))
            val bw = (w * d * k).toInt().coerceAtLeast(2)
            val bh = (h * d * k).toInt().coerceAtLeast(2)
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val r = round / 100f * minOf(bw, bh) / 2f
            Canvas(bmp).drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), r, r,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
            return bmp
        }

        private val rows = listOf(
            intArrayOf(R.id.w_r1, R.id.w_n1, R.id.w_k1, R.id.w_t1),
            intArrayOf(R.id.w_r2, R.id.w_n2, R.id.w_k2, R.id.w_t2))

        private fun draw(ctx: Context, m: AppWidgetManager, ids: IntArray) {
            val c = Cfg.p(ctx)
            val noBg = c.getBoolean("nobg", true)
            val round = c.getInt("round", 25)
            val g = 255 - c.getInt("bg", 100) * 255 / 100
            val alpha = c.getInt("opacity", 100) * 255 / 100
            val fg = if (noBg) { val f = 255 - c.getInt("font", 0) * 255 / 100; Color.rgb(f, f, f) }
                     else if (g > 127) Color.BLACK else Color.WHITE
            val cities = c.getBoolean("weather", true)
            val goldOn = c.getBoolean("gold_on", true)
            val gold = if (goldOn) Gold.perGram(ctx) else null
            val rate = Rates.cross(Rates.all(ctx), "EUR", "INR")
            val d = ctx.resources.displayMetrics.density

            for (id in ids) {
                val o = m.getAppWidgetOptions(id)
                val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 200).toFloat()
                val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110).toFloat()
                val padDp = 8f + round / 100f * 0.10f * minOf(w, h)
                // all three sections share one font size; extra gap = 30% of a line before the 1st city row and before gold
                val units = 1f + (if (cities) 2f + 0.36f else 0f) + (if (goldOn) 1f + 0.36f else 0f) + 0.9f
                val s = minOf((w - 2 * padDp) / 10f, (h - 2 * padDp) / (1.4f * units)).coerceIn(8f, 40f)
                val gap = (0.36f * s * d).toInt()
                val lp = (0.35f * s * d).toInt()
                val pad = (padDp * d).toInt()
                val sp = TypedValue.COMPLEX_UNIT_SP

                val v = RemoteViews(ctx.packageName, R.layout.widget)
                if (noBg) v.setViewVisibility(R.id.bg, View.GONE) else {
                    v.setViewVisibility(R.id.bg, View.VISIBLE)
                    v.setImageViewBitmap(R.id.bg, bgBitmap(w, h, d, round, Color.argb(alpha, g, g, g)))
                }
                v.setViewPadding(R.id.w_content, pad, pad, pad, pad)

                v.setTextViewText(R.id.w_main, if (rate != null) String.format(Locale.US, "1 € = ₹ %.2f", rate) else "No data")
                v.setTextViewTextSize(R.id.w_main, sp, s); v.setTextColor(R.id.w_main, fg)

                for ((i, r) in rows.withIndex()) {
                    val slot = i + 1
                    val city = Weather.city(ctx, slot)
                    val t = Weather.temp(ctx, slot)
                    v.setViewVisibility(r[0], if (cities) View.VISIBLE else View.GONE)
                    v.setViewPadding(r[0], 0, if (i == 0) gap else 0, 0, 0)       // same row spacing between city rows
                    v.setTextViewText(r[1], city.name)
                    v.setString(r[2], "setTimeZone", city.tz)                       // live 24-hour clock
                    v.setTextViewText(r[3], t?.let { String.format(Locale.US, "%.0f°C", it) } ?: "—")
                    v.setTextViewTextSize(r[1], sp, s); v.setTextViewTextSize(r[2], sp, s)
                    v.setTextViewTextSize(r[3], sp, s * 0.7f)                       // temperature 30% smaller, same baseline
                    v.setViewPadding(r[2], lp, 0, 0, 0); v.setViewPadding(r[3], lp, 0, 0, 0)
                    for (k in 1..3) v.setTextColor(r[k], fg)
                }

                v.setViewVisibility(R.id.w_gold, if (goldOn) View.VISIBLE else View.GONE)
                v.setViewPadding(R.id.w_gold, 0, gap, 0, 0)
                v.setTextViewText(R.id.w_gold, if (gold != null)
                    String.format(Locale.US, if (gold.first < 100) "Gold  %,.2f %s/g" else "Gold  %,.0f %s/g", gold.first, gold.second)
                    else "Gold  —")
                v.setTextViewTextSize(R.id.w_gold, sp, s); v.setTextColor(R.id.w_gold, fg)

                v.setTextViewText(R.id.w_refresh, "⟳")
                v.setTextViewTextSize(R.id.w_refresh, sp, (s * 0.72f).coerceAtLeast(11f))
                v.setTextColor(R.id.w_refresh, fg)

                v.setOnClickPendingIntent(R.id.w_root,
                    PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
                val refresh = Intent(ctx, RateWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                v.setOnClickPendingIntent(R.id.w_refresh,
                    PendingIntent.getBroadcast(ctx, 1, refresh, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                m.updateAppWidget(id, v)
            }
        }
    }
}
