package com.example.eurinr

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class RateWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        draw(ctx, m, ids)
        val pending = goAsync()
        Thread {
            Rates.fetch(ctx)
            draw(ctx, m, ids)
            pending.finish()
        }.start()
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        draw(ctx, m, intArrayOf(id))            // resized: redraw with new text size
    }

    companion object {
        fun redraw(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RateWidget::class.java))
            if (ids.isNotEmpty()) draw(ctx, m, ids)
        }

        private fun draw(ctx: Context, m: AppWidgetManager, ids: IntArray) {
            val c = Cfg.p(ctx)
            val noBg = c.getBoolean("nobg", false)
            val circle = c.getBoolean("circle", false)
            val g = 255 - c.getInt("bg", 100) * 255 / 100              // 0 = white ... 100 = black
            val bgColor = Color.rgb(g, g, g)
            val alpha = c.getInt("opacity", 100) * 255 / 100
            val fg = if (noBg) { val f = 255 - c.getInt("font", 0) * 255 / 100; Color.rgb(f, f, f) }
                     else if (g > 127) Color.BLACK else Color.WHITE
            val rate = Rates.cross(Rates.all(ctx), "EUR", "INR")
            val d = ctx.resources.displayMetrics.density
            val t = Rates.time(ctx)

            for (id in ids) {
                val o = m.getAppWidgetOptions(id)
                val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180).toFloat()
                val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110).toFloat()
                val s = (if (circle) minOf(w, h) / 9f else minOf(w / 7.5f, h / 3.2f)).coerceIn(9f, 44f)
                val pad = if (circle) (minOf(w, h) * 0.14f * d).toInt() else (8 * d).toInt()

                val v = RemoteViews(ctx.packageName, R.layout.widget)
                v.setViewVisibility(R.id.bg_round, if (!noBg && !circle) View.VISIBLE else View.GONE)
                v.setViewVisibility(R.id.bg_circle, if (!noBg && circle) View.VISIBLE else View.GONE)
                for (bg in intArrayOf(R.id.bg_round, R.id.bg_circle)) {
                    v.setInt(bg, "setColorFilter", bgColor)
                    v.setInt(bg, "setImageAlpha", alpha)        // only background fades; text stays opaque
                }
                v.setViewPadding(R.id.w_content, pad, pad, pad, pad)

                v.setTextViewText(R.id.w_main, if (rate != null) String.format(Locale.US, "1 € = ₹%.2f", rate) else "No data")
                v.setTextViewText(R.id.w_sub, if (rate != null) String.format(Locale.US, "₹1 = €%.4f", 1 / rate) else "Tap ⟳")
                v.setTextViewText(R.id.w_refresh, "⟳ " + if (t > 0) DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(t)) else "")
                v.setTextViewTextSize(R.id.w_main, TypedValue.COMPLEX_UNIT_SP, s)
                v.setTextViewTextSize(R.id.w_sub, TypedValue.COMPLEX_UNIT_SP, s * 0.7f)
                v.setTextViewTextSize(R.id.w_refresh, TypedValue.COMPLEX_UNIT_SP, (s * 0.6f).coerceAtLeast(9f))
                for (tv in intArrayOf(R.id.w_main, R.id.w_sub, R.id.w_refresh)) v.setTextColor(tv, fg)

                v.setOnClickPendingIntent(R.id.w_root,
                    PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
                val refresh = Intent(ctx, RateWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                v.setOnClickPendingIntent(R.id.w_refresh,
                    PendingIntent.getBroadcast(ctx, 1, refresh, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                m.updateAppWidget(id, v)
            }
        }
    }
}
