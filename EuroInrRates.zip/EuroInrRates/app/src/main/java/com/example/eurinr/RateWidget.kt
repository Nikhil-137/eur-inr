package com.example.eurinr

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import java.util.Locale

class RateWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        draw(ctx, m, ids)
        val pending = goAsync()
        Thread {
            Rates.fetch(ctx)
            draw(ctx, m, ids)
            pending.finish()
        }.start()
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, m: AppWidgetManager, id: Int, o: Bundle) {
        draw(ctx, m, intArrayOf(id))
    }

    companion object {
        fun redraw(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RateWidget::class.java))
            if (ids.isNotEmpty()) draw(ctx, m, ids)
        }

        private fun bgBitmap(w: Float, h: Float, d: Float, round: Int, color: Int): Bitmap {
            val k = minOf(1f, 600f / (maxOf(w, h) * d))
            val bw = (w * d * k).toInt().coerceAtLeast(2)
            val bh = (h * d * k).toInt().coerceAtLeast(2)
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val r = round / 100f * minOf(bw, bh) / 2f          // 100 = fully round ends
            Canvas(bmp).drawRoundRect(RectF(0f, 0f, bw.toFloat(), bh.toFloat()), r, r,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
            return bmp
        }

        private fun draw(ctx: Context, m: AppWidgetManager, ids: IntArray) {
            val c = Cfg.p(ctx)
            val noBg = c.getBoolean("nobg", false)
            val round = c.getInt("round", 25)
            val g = 255 - c.getInt("bg", 100) * 255 / 100              // 0 = white ... 100 = black
            val alpha = c.getInt("opacity", 100) * 255 / 100
            val fg = if (noBg) { val f = 255 - c.getInt("font", 0) * 255 / 100; Color.rgb(f, f, f) }
                     else if (g > 127) Color.BLACK else Color.WHITE
            val rate = Rates.cross(Rates.all(ctx), "EUR", "INR")
            val d = ctx.resources.displayMetrics.density

            for (id in ids) {
                val o = m.getAppWidgetOptions(id)
                val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180).toFloat()
                val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110).toFloat()
                val padDp = 8f + round / 100f * 0.10f * minOf(w, h)     // keep text inside rounded corners
                val s = minOf((w - 2 * padDp) / 7.8f, h / 3.2f).coerceIn(9f, 44f)
                val pad = (padDp * d).toInt()

                val v = RemoteViews(ctx.packageName, R.layout.widget)
                if (noBg) v.setViewVisibility(R.id.bg, View.GONE) else {
                    v.setViewVisibility(R.id.bg, View.VISIBLE)
                    v.setImageViewBitmap(R.id.bg, bgBitmap(w, h, d, round, Color.argb(alpha, g, g, g)))
                }
                v.setViewPadding(R.id.w_content, pad, pad, pad, pad)
                v.setTextViewText(R.id.w_main,
                    if (rate != null) String.format(Locale.US, "1 € = ₹ %.2f", rate) else "No data")
                v.setTextViewText(R.id.w_refresh, "⟳")
                v.setTextViewTextSize(R.id.w_main, TypedValue.COMPLEX_UNIT_SP, s)
                v.setTextViewTextSize(R.id.w_refresh, TypedValue.COMPLEX_UNIT_SP, (s * 0.72f).coerceAtLeast(11f))
                v.setTextColor(R.id.w_main, fg); v.setTextColor(R.id.w_refresh, fg)

                v.setOnClickPendingIntent(R.id.w_root,
                    PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
                val refresh = Intent(ctx, RateWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                v.setOnClickPendingIntent(R.id.w_refresh,
                    PendingIntent.getBroadcast(ctx, 1, refresh, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                m.updateAppWidget(id, v)
            }
        }
    }
}
