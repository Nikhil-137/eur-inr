package com.example.eurinr

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class RateWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        draw(ctx, m, ids)                       // show cached value immediately
        val pending = goAsync()
        Thread {
            Rates.fetch(ctx)
            draw(ctx, m, ids)
            pending.finish()
        }.start()
    }

    private fun draw(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        val rate = Rates.cached(ctx)
        val v = RemoteViews(ctx.packageName, R.layout.widget)
        if (rate != null) {
            v.setTextViewText(R.id.w_main, String.format(Locale.US, "1 € = ₹%.2f", rate))
            v.setTextViewText(R.id.w_sub, String.format(Locale.US, "₹1 = €%.4f", 1 / rate))
            v.setTextViewText(R.id.w_time, "Updated " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(Rates.cachedTime(ctx))))
        } else {
            v.setTextViewText(R.id.w_main, "No data yet")
            v.setTextViewText(R.id.w_sub, "Tap ⟳ to load")
            v.setTextViewText(R.id.w_time, "")
        }
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        v.setOnClickPendingIntent(R.id.w_root, open)
        val refresh = Intent(ctx, RateWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
        v.setOnClickPendingIntent(R.id.w_refresh,
            PendingIntent.getBroadcast(ctx, 1, refresh, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        m.updateAppWidget(ids, v)
    }

    companion object {
        fun updateAll(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, RateWidget::class.java))
            if (ids.isNotEmpty()) ctx.sendBroadcast(Intent(ctx, RateWidget::class.java)
                .setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids))
        }
    }
}
