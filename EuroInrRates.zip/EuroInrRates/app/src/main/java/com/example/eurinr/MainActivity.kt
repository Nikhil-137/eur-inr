package com.example.eurinr

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : BaseActivity() {
    private var rate = 0.0
    private var busy = false
    private var map: Map<String, Double> = emptyMap()
    private var codes: List<String> = listOf("USD", "EUR", "INR")
    private lateinit var a1: EditText
    private lateinit var a2: EditText
    private lateinit var c1: TextView
    private lateinit var c2: TextView
    private lateinit var cg: TextView
    private lateinit var info: TextView
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private lateinit var timeRows: List<View>
    private lateinit var weatherRows: List<View>
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 60_000) } }
    private val clock = object : Runnable { override fun run() { showTime(); h.postDelayed(this, 1000) } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        pages = listOf(R.id.page_convert, R.id.page_time, R.id.page_weather, R.id.page_gold).map { findViewById<View>(it) }
        tabs = listOf(R.id.tab_convert, R.id.tab_time, R.id.tab_weather, R.id.tab_gold).map { findViewById<TextView>(it) }
        tabs.forEachIndexed { i, t -> t.setOnClickListener { show(i) } }
        findViewById<View>(R.id.tab_settings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        show(0)

        a1 = findViewById(R.id.amt1); a2 = findViewById(R.id.amt2)
        c1 = findViewById(R.id.sp1); c2 = findViewById(R.id.sp2); cg = findViewById(R.id.sp_gold)
        info = findViewById(R.id.info)
        findViewById<View>(R.id.refresh).setOnClickListener { refresh() }
        watch(a1, a2, true); watch(a2, a1, false)
        c1.setOnClickListener { pickCurrency("from") { recompute() } }
        c2.setOnClickListener { pickCurrency("to") { recompute() } }
        cg.setOnClickListener { pickCurrency("gold_cur") { showGold() } }
        a1.setText("1")

        timeRows = buildRows(findViewById(R.id.time_list))
        weatherRows = buildRows(findViewById(R.id.weather_list))
        map = Rates.all(this)
        updateCodes(); recompute(); showTime(); showWeather(); showGold()
    }

    override fun onResume() { super.onResume(); h.post(tick); h.post(clock) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); h.removeCallbacks(clock) }

    private fun show(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        val accent = resources.getColor(R.color.accent, theme); val sub = resources.getColor(R.color.sub, theme)
        tabs.forEachIndexed { k, t -> t.setTextColor(if (k == i) accent else sub) }
    }

    // ---------- currency ----------
    private fun cur(key: String, def: String) = Cfg.p(this).getString(key, def) ?: def

    private fun updateCodes() {
        codes = if (map.isEmpty()) listOf("USD", "EUR", "INR") else Rates.ordered(map)
        c1.text = Rates.label(cur("from", "EUR")); c2.text = Rates.label(cur("to", "INR")); cg.text = Rates.label(cur("gold_cur", "INR"))
    }

    /** Dialog with a search box: type a code or name (e.g. "INR", "rupee") to filter. */
    private fun pickCurrency(key: String, after: () -> Unit) {
        val all = codes.map { it to Rates.label(it) }
        var shown = all
        val d = resources.displayMetrics.density
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((16 * d).toInt(), (8 * d).toInt(), (16 * d).toInt(), 0) }
        val q = EditText(this).apply {
            hint = "Search currency (code or name)"; inputType = InputType.TYPE_CLASS_TEXT; isSingleLine = true
            setTextColor(resources.getColor(R.color.text, theme)); setHintTextColor(resources.getColor(R.color.sub, theme))
        }
        val lv = ListView(this)
        val ad = ArrayAdapter(this, R.layout.spinner_dropdown, all.map { it.second }.toMutableList())
        lv.adapter = ad
        box.addView(q); box.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.45).toInt()))
        val dlg = AlertDialog.Builder(this).setTitle("Select currency").setView(box).create()
        q.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val t = e.toString().trim()
                shown = all.filter { it.second.contains(t, ignoreCase = true) }
                ad.clear(); ad.addAll(shown.map { it.second })
            }
        })
        lv.setOnItemClickListener { _, _, i, _ ->
            Cfg.p(this).edit().putString(key, shown[i].first).apply()
            updateCodes(); after(); dlg.dismiss()
        }
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
    }

    private fun recompute() {
        rate = Rates.cross(map, cur("from", "EUR"), cur("to", "INR")) ?: 0.0
        convert(a1, a2, true); showRate(false)
    }

    private fun watch(src: EditText, dst: EditText, fwd: Boolean) {
        src.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) { if (!busy) convert(src, dst, fwd) }
        })
    }

    private fun convert(src: EditText, dst: EditText, fwd: Boolean) {
        val v = src.text.toString().replace(',', '.').toDoubleOrNull()
        busy = true
        dst.setText(if (v == null || rate == 0.0) "" else String.format(Locale.US, "%.2f", if (fwd) v * rate else v / rate))
        busy = false
    }

    private fun showRate(failed: Boolean) {
        info.text = if (rate == 0.0) "No rate yet. Check your connection." else
            String.format(Locale.US, "1 %s = %.4f %s%s", cur("from", "EUR"), rate, cur("to", "INR"), if (failed) "  (offline, last known)" else "")
    }

    // ---------- cities (shared by Time and Weather) ----------
    private fun buildRows(container: LinearLayout): List<View> = (1..Weather.SLOTS).map { slot ->
        val v = layoutInflater.inflate(R.layout.item_city, container, false)
        container.addView(v)
        setupCity(slot, v.findViewById(R.id.i_q), v.findViewById(R.id.i_btn))
        v
    }

    private fun setupCity(slot: Int, q: EditText, btn: View) {
        btn.setOnClickListener {
            val text = q.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            Thread {
                val r = try { Weather.search(text) } catch (_: Exception) { emptyList() }
                runOnUiThread {
                    if (r.isEmpty()) Toast.makeText(this, "No city found", Toast.LENGTH_SHORT).show()
                    else AlertDialog.Builder(this).setTitle("Choose city")
                        .setItems(r.map { it.label() }.toTypedArray()) { _, i ->
                            Weather.setCity(this, slot, r[i]); q.setText(""); showTime(); showWeather(); RateWidget.redraw(this)
                            Thread { Weather.refresh(this); runOnUiThread { showWeather(); RateWidget.redraw(this) } }.start()
                        }.show()
                }
            }.start()
        }
    }

    private fun showTime() {
        val now = Date()
        for (n in 1..Weather.SLOTS) {
            val c = Weather.city(this, n); val tz = TimeZone.getTimeZone(c.tz)
            val r = timeRows[n - 1]
            r.findViewById<TextView>(R.id.i_label).text = c.label()
            r.findViewById<TextView>(R.id.i_value).text = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = tz }.format(now)
            r.findViewById<TextView>(R.id.i_sub).text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).apply { timeZone = tz }.format(now)
        }
    }

    private fun showWeather() {
        for (n in 1..Weather.SLOTS) {
            val r = weatherRows[n - 1]
            r.findViewById<TextView>(R.id.i_label).text = Weather.city(this, n).label()
            r.findViewById<TextView>(R.id.i_value).text = Weather.temp(this, n)?.let { String.format(Locale.US, "%.0f°C", it) } ?: "—"
            r.findViewById<TextView>(R.id.i_sub).visibility = View.GONE
        }
    }

    // ---------- gold ----------
    private fun showGold() {
        val cu = cur("gold_cur", "INR")
        val usd = Gold.cached(this); val k = Rates.cross(map, "USD", cu)
        val m = findViewById<TextView>(R.id.gold_main); val r = findViewById<TextView>(R.id.gold_rows)
        if (usd == null || k == null) { m.text = "—"; r.text = "Waiting for data…"; return }
        val g = usd / 31.1035 * k
        m.text = String.format(Locale.US, "%,.2f %s", g, cu)
        r.text = String.format(Locale.US, "22K per gram   %,.2f\n18K per gram   %,.2f\n24K per 10 g   %,.2f\nPer troy ounce   %,.2f",
            g * 22 / 24, g * 18 / 24, g * 10, usd * k)
    }

    // ---------- refresh ----------
    private fun refresh() {
        info.text = "Updating…"
        Thread {
            val ok = Sync.all(this)
            runOnUiThread {
                if (ok) { map = Rates.all(this); updateCodes(); recompute() }
                showRate(!ok); showWeather(); showGold(); RateWidget.redraw(this)
            }
        }.start()
    }
}
