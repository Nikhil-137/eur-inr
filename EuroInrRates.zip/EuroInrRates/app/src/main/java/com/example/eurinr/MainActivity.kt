package com.example.eurinr

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private var rate = 0.0          // INR per 1 EUR
    private var busy = false
    private lateinit var eur: EditText
    private lateinit var inr: EditText
    private lateinit var info: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 60_000) }   // live refresh every minute
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        eur = findViewById(R.id.eur); inr = findViewById(R.id.inr); info = findViewById(R.id.info)
        findViewById<android.view.View>(R.id.refresh).setOnClickListener { refresh() }
        rate = Rates.cached(this) ?: 0.0
        watch(eur, inr, true)
        watch(inr, eur, false)
        eur.setText("1")
        showRate()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun watch(src: EditText, dst: EditText, toInr: Boolean) {
        src.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (busy) return
                convert(src, dst, toInr)
            }
        })
    }

    private fun convert(src: EditText, dst: EditText, toInr: Boolean) {
        val v = src.text.toString().replace(',', '.').toDoubleOrNull()
        busy = true
        dst.setText(if (v == null || rate == 0.0) "" else
            String.format(Locale.US, "%.2f", if (toInr) v * rate else v / rate))
        busy = false
    }

    private fun refresh() {
        info.text = "Updating…"
        Thread {
            val r = Rates.fetch(this)
            runOnUiThread {
                if (r != null) { rate = r; convert(eur, inr, true); RateWidget.updateAll(this) }
                showRate(r == null)
            }
        }.start()
    }

    private fun showRate(failed: Boolean = false) {
        info.text = when {
            rate == 0.0 -> "No rate yet. Check your connection and tap Refresh."
            failed -> String.format(Locale.US, "1 € = ₹%.4f (offline, last known rate)", rate)
            else -> String.format(Locale.US, "1 € = ₹%.4f  •  ₹1 = €%.5f", rate, 1 / rate)
        }
    }
}
