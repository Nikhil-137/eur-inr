package com.example.eurinr

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : BaseActivity() {
    private var rate = 0.0
    private var busy = false
    private var map: Map<String, Double> = emptyMap()
    private var codes: List<String> = emptyList()
    private lateinit var a1: EditText
    private lateinit var a2: EditText
    private lateinit var sp1: Spinner
    private lateinit var sp2: Spinner
    private lateinit var spG: Spinner
    private lateinit var info: TextView
    private lateinit var pages: List<View>
    private lateinit var tabs: List<TextView>
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 60_000) } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        pages = listOf(R.id.page_convert, R.id.page_weather, R.id.page_gold).map { findViewById<View>(it) }
        tabs = listOf(R.id.tab_convert, R.id.tab_weather, R.id.tab_gold).map { findViewById<TextView>(it) }
        tabs.forEachIndexed { i, t -> t.setOnClickListener { show(i) } }
        findViewById<View>(R.id.tab_settings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        show(0)

        a1 = findViewById(R.id.amt1); a2 = findViewById(R.id.amt2)
        sp1 = findViewById(R.id.sp1); sp2 = findViewById(R.id.sp2); spG = findViewById(R.id.sp_gold)
        info = findViewById(R.id.info)
        findViewById<View>(R.id.refresh).setOnClickListener { refresh() }
        watch(a1, a2, true); watch(a2, a1, false)
        val sel = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (codes.isEmpty()) return
                val key = when { p === sp1 -> "from"; p === sp2 -> "to"; else -> "gold_cur" }
                Cfg.p(this@MainActivity).edit().putString(key, codes[pos]).apply()
                if (p === spG) showGold() else recompute()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        sp1.onItemSelectedListener = sel; sp2.onItemSelectedListener = sel; spG.onItemSelectedListener = sel
        a1.setText("1")
        map = Rates.all(this)
        loadCodes()
        for (n in 1..2) setupCity(n, findViewById(if (n == 1) R.id.c1_q else R.id.c2_q), findViewById(if (n == 1) R.id.c1_btn else R.id.c2_btn))
        showWeather(); showGold()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun show(i: Int) {
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        val accent = resources.getColor(R.color.accent, theme); val sub = resources.getColor(R.color.sub, theme)
        tabs.forEachIndexed { k, t -> t.setTextColor(if (k == i) accent else sub) }
    }

    // ---------- converter ----------
    private fun loadCodes() {
        val list = if (map.isEmpty()) listOf("USD", "EUR", "INR") else Rates.ordered(map)
        if (list == codes) return
        codes = list
        val ad = ArrayAdapter(this, R.layout.spinner_item, list.map { Rates.label(it) })
        ad.setDropDownViewResource(R.layout.spinner_dropdown)
        val p = Cfg.p(this)
        sp1.adapter = ad; sp2.adapter = ad; spG.adapter = ad
        sp1.setSelection(list.indexOf(p.getString("from", "EUR")).coerceAtLeast(0))
        sp2.setSelection(list.indexOf(p.getString("to", "INR")).coerceAtLeast(0))
        spG.setSelection(list.indexOf(p.getString("gold_cur", "INR")).coerceAtLeast(0))
        recompute()
    }

    private fun code(sp: Spinner) = codes.getOrNull(sp.selectedItemPosition)

    private fun recompute() {
        rate = Rates.cross(map, code(sp1), code(sp2)) ?: 0.0
        convert(a1, a2, true); showRate(false)
    }

    private fun watch(src: EditText, dst: EditText, fwd: Boolean) {
        src.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) { if (!busy) convert(src, dst, fwd) }
        })
    }

    private fun convert(src: EditText, dst: EditText, fwd: Boolean) {
        val v = src.text.toString().replace(',', '.').toDoubleOrNull()
        busy = true
        dst.setText(if (v == null || rate == 0.0) "" else String.format(Locale.US, "%.2f", if (fwd) v * rate else v / rate))
        busy = false
    }

    private fun showRate(failed: Boolean) {
        info.text = if (rate == 0.0) "No rate yet. Check your connection." else
            String.format(Locale.US, "1 %s = %.4f %s%s", code(sp1), rate, code(sp2), if (failed) "  (offline, last known)" else "")
    }

    // ---------- weather ----------
    private fun setupCity(slot: Int, q: EditText, btn: View) {
        btn.setOnClickListener {
            val text = q.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            Thread {
                val r = try { Weather.search(text) } catch (_: Exception) { emptyList() }
                runOnUiThread {
                    if (r.isEmpty()) Toast.makeText(this, "No city found", Toast.LENGTH_SHORT).show()
                    else AlertDialog.Builder(this).setTitle("Choose city")
                        .setItems(r.map { it.label() }.toTypedArray()) { _, i ->
                            Weather.setCity(this, slot, r[i]); q.setText(""); showWeather()
                            Thread { Weather.refresh(this); runOnUiThread { showWeather(); RateWidget.redraw(this) } }.start()
                        }.show()
                }
            }.start()
        }
    }

    private fun showWeather() {
        for (n in 1..2) {
            findViewById<TextView>(if (n == 1) R.id.c1_name else R.id.c2_name).text = Weather.city(this, n).label()
            findViewById<TextView>(if (n == 1) R.id.c1_temp else R.id.c2_temp).text =
                Weather.temp(this, n)?.let { String.format(Locale.US, "%.0f°C", it) } ?: "—"
        }
    }

    // ---------- gold ----------
    private fun showGold() {
        val cur = Cfg.p(this).getString("gold_cur", "INR")
        val usd = Gold.cached(this); val k = Rates.cross(map, "USD", cur)
        val m = findViewById<TextView>(R.id.gold_main); val r = findViewById<TextView>(R.id.gold_rows)
        if (usd == null || k == null) { m.text = "—"; r.text = "Waiting for data…"; return }
        val g = usd / 31.1035 * k
        m.text = String.format(Locale.US, "%,.2f %s", g, cur)
        r.text = String.format(Locale.US, "22K per gram   %,.2f\n18K per gram   %,.2f\n24K per 10 g   %,.2f\nPer troy ounce   %,.2f",
            g * 22 / 24, g * 18 / 24, g * 10, usd * k)
    }

    // ---------- refresh ----------
    private fun refresh() {
        info.text = "Updating…"
        Thread {
            val ok = Sync.all(this)
            runOnUiThread {
                if (ok) { map = Rates.all(this); loadCodes(); recompute() }
                showRate(!ok); showWeather(); showGold(); RateWidget.redraw(this)
            }
        }.start()
    }
}
