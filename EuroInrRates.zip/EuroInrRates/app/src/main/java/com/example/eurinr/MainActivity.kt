package com.example.eurinr

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private var rate = 0.0                  // units of "to" per 1 "from"
    private var busy = false
    private var map: Map<String, Double> = emptyMap()
    private var codes: List<String> = emptyList()
    private lateinit var a1: EditText
    private lateinit var a2: EditText
    private lateinit var sp1: Spinner
    private lateinit var sp2: Spinner
    private lateinit var info: TextView
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 60_000) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        a1 = findViewById(R.id.amt1); a2 = findViewById(R.id.amt2)
        sp1 = findViewById(R.id.sp1); sp2 = findViewById(R.id.sp2); info = findViewById(R.id.info)
        findViewById<View>(R.id.refresh).setOnClickListener { refresh() }
        findViewById<View>(R.id.settings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        watch(a1, a2, true); watch(a2, a1, false)
        val sel = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (codes.isEmpty()) return
                Cfg.p(this@MainActivity).edit()
                    .putString(if (p === sp1) "from" else "to", codes[pos]).apply()
                recompute()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        sp1.onItemSelectedListener = sel; sp2.onItemSelectedListener = sel
        a1.setText("1")
        map = Rates.all(this)
        loadCodes()
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun loadCodes() {
        val list = if (map.isEmpty()) listOf("USD", "EUR", "INR") else Rates.ordered(map)
        if (list == codes) return
        codes = list
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, list.map { Rates.label(it) })
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        val p = Cfg.p(this)
        sp1.adapter = ad; sp2.adapter = ad
        sp1.setSelection(list.indexOf(p.getString("from", "EUR")).coerceAtLeast(0))
        sp2.setSelection(list.indexOf(p.getString("to", "INR")).coerceAtLeast(0))
        recompute()
    }

    private fun code(sp: Spinner) = codes.getOrNull(sp.selectedItemPosition)

    private fun recompute() {
        rate = Rates.cross(map, code(sp1), code(sp2)) ?: 0.0
        convert(a1, a2, true)
        showRate(false)
    }

    private fun watch(src: EditText, dst: EditText, fwd: Boolean) {
        src.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun afterTextChanged(e: Editable?) { if (!busy) convert(src, dst, fwd) }
        })
    }

    private fun convert(src: EditText, dst: EditText, fwd: Boolean) {
        val v = src.text.toString().replace(',', '.').toDoubleOrNull()
        busy = true
        dst.setText(if (v == null || rate == 0.0) "" else
            String.format(Locale.US, "%.2f", if (fwd) v * rate else v / rate))
        busy = false
    }

    private fun refresh() {
        info.text = "Updating…"
        Thread {
            val ok = Rates.fetch(this)
            runOnUiThread {
                if (ok) { map = Rates.all(this); loadCodes(); recompute(); RateWidget.redraw(this) }
                showRate(!ok)
            }
        }.start()
    }

    private fun showRate(failed: Boolean) {
        info.text = when {
            rate == 0.0 -> "No rate yet. Check your connection and tap Refresh."
            else -> String.format(Locale.US, "1 %s = %.4f %s%s", code(sp1), rate, code(sp2),
                if (failed) "  (offline, last known)" else "")
        }
    }
}
