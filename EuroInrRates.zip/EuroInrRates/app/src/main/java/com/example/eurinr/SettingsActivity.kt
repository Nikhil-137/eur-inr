package com.example.eurinr

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CompoundButton
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch

class SettingsActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_settings)
        bar(R.id.s_round, "round", 25); bar(R.id.s_opacity, "opacity", 100)
        bar(R.id.s_bg, "bg", 100); bar(R.id.s_font, "font", 0)
        sw(R.id.sw_nobg, "nobg", true); sw(R.id.sw_weather, "weather", true); sw(R.id.sw_gold, "gold_on", true)
        enable()
        val sp = findViewById<Spinner>(R.id.sp_theme)
        val ad = ArrayAdapter(this, R.layout.spinner_item, listOf("Follow system", "Light", "Dark"))
        ad.setDropDownViewResource(R.layout.spinner_dropdown)
        sp.adapter = ad
        sp.setSelection(Cfg.p(this).getInt("theme", 0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos != Cfg.p(this@SettingsActivity).getInt("theme", 0)) {
                    Cfg.p(this@SettingsActivity).edit().putInt("theme", pos).apply()
                    recreate()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun bar(id: Int, key: String, def: Int) {
        val p = Cfg.p(this)
        val b = findViewById<SeekBar>(id)
        b.progress = p.getInt(key, def)
        b.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, user: Boolean) {
                p.edit().putInt(key, v).apply(); RateWidget.redraw(this@SettingsActivity)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun sw(id: Int, key: String, def: Boolean) {
        val p = Cfg.p(this)
        val b = findViewById<Switch>(id)
        b.isChecked = p.getBoolean(key, def)
        b.setOnCheckedChangeListener { _: CompoundButton, on: Boolean ->
            p.edit().putBoolean(key, on).apply(); enable(); RateWidget.redraw(this)
        }
    }

    private fun enable() {
        val noBg = Cfg.p(this).getBoolean("nobg", true)
        for (i in intArrayOf(R.id.s_round, R.id.s_opacity, R.id.s_bg)) findViewById<SeekBar>(i).isEnabled = !noBg
        findViewById<SeekBar>(R.id.s_font).isEnabled = noBg
    }
}
