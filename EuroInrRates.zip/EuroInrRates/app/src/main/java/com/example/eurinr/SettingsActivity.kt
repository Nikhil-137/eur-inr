package com.example.eurinr

import android.app.Activity
import android.os.Bundle
import android.widget.CompoundButton
import android.widget.SeekBar
import android.widget.Switch

class SettingsActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_settings)
        bar(R.id.s_opacity, "opacity", 100)
        bar(R.id.s_bg, "bg", 100)
        bar(R.id.s_font, "font", 0)
        bar(R.id.s_round, "round", 25)
        sw(R.id.sw_nobg, "nobg")
        enable()
    }

    private fun bar(id: Int, key: String, def: Int) {
        val p = Cfg.p(this)
        val b = findViewById<SeekBar>(id)
        b.progress = p.getInt(key, def)
        b.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, user: Boolean) {
                p.edit().putInt(key, v).apply(); RateWidget.redraw(this@SettingsActivity)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun sw(id: Int, key: String) {
        val p = Cfg.p(this)
        val b = findViewById<Switch>(id)
        b.isChecked = p.getBoolean(key, false)
        b.setOnCheckedChangeListener { _: CompoundButton, on: Boolean ->
            p.edit().putBoolean(key, on).apply(); enable(); RateWidget.redraw(this)
        }
    }

    /** Background sliders apply only with a background; font slider only without one. */
    private fun enable() {
        val noBg = Cfg.p(this).getBoolean("nobg", false)
        findViewById<SeekBar>(R.id.s_round).isEnabled = !noBg
        findViewById<SeekBar>(R.id.s_opacity).isEnabled = !noBg
        findViewById<SeekBar>(R.id.s_bg).isEnabled = !noBg
        findViewById<SeekBar>(R.id.s_font).isEnabled = noBg
    }
}
