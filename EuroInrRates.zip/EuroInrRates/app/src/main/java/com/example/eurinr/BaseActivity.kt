package com.example.eurinr

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

/** Applies the in-app theme choice (0 = system, 1 = light, 2 = dark). */
open class BaseActivity : Activity() {
    private var applied = 0

    override fun attachBaseContext(b: Context) {
        applied = Cfg.p(b).getInt("theme", 0)
        if (applied == 0) { super.attachBaseContext(b); return }
        val cfg = Configuration(b.resources.configuration)
        cfg.uiMode = (cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
            (if (applied == 2) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO)
        super.attachBaseContext(b.createConfigurationContext(cfg))
    }

    override fun onResume() {
        super.onResume()
        if (Cfg.p(this).getInt("theme", 0) != applied) recreate()
    }
}
