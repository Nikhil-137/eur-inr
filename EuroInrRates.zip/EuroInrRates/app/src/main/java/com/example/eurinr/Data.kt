package com.example.eurinr

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        try { return c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }
}

data class City(val name: String, val country: String, val lat: String, val lon: String) {
    fun label() = if (country.isEmpty()) name else "$name, $country"
    fun pack() = listOf(name, country, lat, lon).joinToString("|")
}

object Weather {
    private val defaults = mapOf(
        1 to City("Mumbai", "India", "19.0760", "72.8777"),
        2 to City("Paris", "France", "48.8566", "2.3522"))

    fun city(ctx: Context, slot: Int): City {
        val p = Cfg.p(ctx).getString("city$slot", null)?.split("|")
        return if (p != null && p.size == 4) City(p[0], p[1], p[2], p[3]) else defaults.getValue(slot)
    }

    fun setCity(ctx: Context, slot: Int, c: City) {
        Cfg.p(ctx).edit().putString("city$slot", c.pack()).remove("temp$slot").apply()
    }

    fun temp(ctx: Context, slot: Int): Float? =
        Cfg.p(ctx).getFloat("temp$slot", Float.NaN).takeIf { !it.isNaN() }

    /** Search any city in the world (blocking). */
    fun search(q: String): List<City> {
        val j = JSONObject(Net.get("https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(q, "UTF-8") + "&count=8&language=en&format=json"))
        val a = j.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val region = o.optString("admin1", "")
            val country = o.optString("country", "")
            City(o.getString("name"), listOf(region, country).filter { s -> s.isNotEmpty() }.joinToString(", "),
                o.getDouble("latitude").toString(), o.getDouble("longitude").toString())
        }
    }

    fun refresh(ctx: Context) {
        for (slot in 1..2) try {
            val c = city(ctx, slot)
            val j = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current=temperature_2m"))
            Cfg.p(ctx).edit().putFloat("temp$slot", j.getJSONObject("current").getDouble("temperature_2m").toFloat()).apply()
        } catch (_: Exception) { }
    }
}

object Gold {
    /** Spot price in USD per troy ounce. */
    fun fetch(ctx: Context) {
        val price = try {
            val j = JSONObject(Net.get("https://api.gold-api.com/price/XAU"))
            if (j.has("price")) j.getDouble("price") else j.getDouble("priceUsd")
        } catch (_: Exception) {
            try { JSONObject(Net.get("https://data-asg.goldprice.org/dbXRates/USD"))
                .getJSONArray("items").getJSONObject(0).getDouble("xauPrice") } catch (_: Exception) { null }
        }
        if (price != null && price > 0) Cfg.p(ctx).edit().putLong("gold", price.toRawBits()).apply()
    }

    fun cached(ctx: Context): Double? {
        val p = Cfg.p(ctx)
        return if (p.contains("gold")) Double.fromBits(p.getLong("gold", 0)) else null
    }
}

object Sync {
    /** Blocking: refreshes currencies, weather and gold. Returns whether currency rates updated. */
    fun all(ctx: Context): Boolean {
        val ok = Rates.fetch(ctx)
        Weather.refresh(ctx); Gold.fetch(ctx)
        return ok
    }
}
